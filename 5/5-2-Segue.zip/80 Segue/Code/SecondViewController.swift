//
//  SecondViewController.swift
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

        @IBAction func backButtonPressed(_ sender: Any) {
            dismiss(animated: true, completion: nil)
        }
}
