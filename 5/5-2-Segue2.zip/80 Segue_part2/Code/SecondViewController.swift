//
//  SecondViewController.swift
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var textField: UITextField!
    
    @IBAction func backButtonPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func toThirdVCButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "toThirdVC", sender: nil)
    }
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? ThirdViewController {
            if let textToPass = textField.text {
               destination.text = textToPass
            }
        }
    }
}
