//
//  ViewController.swift
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
    
    @IBAction func unwindToMainViewController(segue:UIStoryboardSegue) { }
}
