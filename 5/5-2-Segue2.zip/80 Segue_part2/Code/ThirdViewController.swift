//
//  ThirdViewController.swift
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    var text: String?

    @IBOutlet weak var textLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let receivedText = text {
            textLabel.text = receivedText
        }
    }

    @IBAction func backButtonPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        
        //Unwind
        //performSegue(withIdentifier: "unwindToMainVC", sender: nil)
    }
}
