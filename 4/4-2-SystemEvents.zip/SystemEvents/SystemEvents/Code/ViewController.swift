//
//  ViewController.swift
//  SystemEvents
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var textField: UITextField!
    private var keyboardWillChangeFrameObserver: NSObjectProtocol?
    
    // MARK: - Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerForKeyboardWillChangeFrameNotification()
        addTapGestureRecognizer()
    }
    // 4
    deinit {
        if let keyboardWillChangeFrameObserver = self.keyboardWillChangeFrameObserver {
            NotificationCenter.default.removeObserver(keyboardWillChangeFrameObserver)
        }
    }
    
    // MARK: - Private
    // 1
    private func registerForKeyboardWillChangeFrameNotification() {
        let keyboardWillChangeFrameClosure = { (notification: Notification) in
            guard let userInfo = notification.userInfo, let keyboardFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue else {
                return
            }
            let convertedKeyboardFrame = self.scrollView.convert(keyboardFrame, from: nil)
            let intersectionFrame = convertedKeyboardFrame.intersection(self.scrollView.frame)
            let keyboardOffset = (convertedKeyboardFrame.intersects(self.textField.frame)) ? intersectionFrame.size.height : 0
            let insets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardOffset, right: 0)
            self.scrollView.contentInset = insets
            self.scrollView.scrollIndicatorInsets = insets
            self.scrollView.scrollRectToVisible(self.textField.frame, animated: true)
        }
        keyboardWillChangeFrameObserver = NotificationCenter.default.addObserver(forName: .UIKeyboardWillChangeFrame, object: nil, queue: .main, using: keyboardWillChangeFrameClosure)
    }
    // 2
    private func addTapGestureRecognizer() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(tapGestureHandler(_:)))
        view.addGestureRecognizer(tapGestureRecognizer)
    }
    
    // MARK: - Actions
    // 3
    @objc
    private func tapGestureHandler(_ sender: UITapGestureRecognizer) {
        textField.resignFirstResponder()
    }
}
