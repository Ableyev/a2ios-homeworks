//
//  Photo.swift
//  UICollectionViewExample
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

struct Photo {
    let name: String
    let image: UIImage
}
