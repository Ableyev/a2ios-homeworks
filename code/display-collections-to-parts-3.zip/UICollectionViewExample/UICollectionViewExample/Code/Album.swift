//
//  Album.swift
//  UICollectionViewExample
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import Foundation

struct Album {
    let name: String
    var photos: [Photo]
}
