//
//  AppDelegate.swift
//  Transitions
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
//        initSimpleHierarchy()
        initComplexHierarchy()
//        initCustomHierarchy()
        
        return true
    }
    
    func initSimpleHierarchy() {
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.backgroundColor = .white
        
        let viewController1 = ViewController1(someData: "VC 1")
        
        let viewController2 = ViewController2(nibName: String(describing: ViewController2.self),
                                              bundle: nil)
        //        let viewController2 = ViewController2(nibName: nil, bundle: nil)
        //        let viewController2 = ViewController2()
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController3 = storyboard.instantiateViewController(withIdentifier: String(describing: ViewController3.self))
        //        storyboard.instantiateInitialViewController()
        
        let tabBarController = UITabBarController()
        tabBarController.setViewControllers([viewController1, viewController2, viewController3], animated: false)
        
        window?.rootViewController = tabBarController
        
        window?.makeKeyAndVisible()
    }
    
    func initComplexHierarchy() {
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.backgroundColor = .white
        
        let masterViewController = MasterViewController()
        let masterNavigationController = UINavigationController(rootViewController: masterViewController)
        
        let detailViewController = DetailViewController()
        
        let splitController = UISplitViewController()
        splitController.viewControllers = [masterNavigationController, detailViewController]
        splitController.delegate = self
        splitController.title = "Split"
        
        let tabBarController = UITabBarController()
        tabBarController.viewControllers = [splitController]
        
        window?.rootViewController = tabBarController
        
        window?.makeKeyAndVisible()
    }
    
    func initCustomHierarchy() {
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.backgroundColor = .white
        
        let viewController1 = UIViewController()
        viewController1.view.backgroundColor = .red
        
        let viewController2 = UIViewController()
        viewController2.view.backgroundColor = .green
        
        let verticalSplitViewController = VerticalSplitViewController()
        verticalSplitViewController.viewControllers = [viewController1, viewController2]
        
        window?.rootViewController = verticalSplitViewController
        
        window?.makeKeyAndVisible()
    }
}

extension AppDelegate: UISplitViewControllerDelegate {
    
    func splitViewController(_ splitViewController: UISplitViewController, separateSecondaryFrom primaryViewController: UIViewController) -> UIViewController? {
        
        if let primaryNavController = primaryViewController as? UINavigationController {
            if let lastVC = primaryNavController.viewControllers.last, lastVC is DetailViewController {
                return nil
            }
        }
        
        return DetailViewController()
    }
}
