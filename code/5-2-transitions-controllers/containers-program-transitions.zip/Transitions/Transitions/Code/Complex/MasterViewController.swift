//
//  MasterViewController.swift
//  Transitions
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class MasterViewController: UIViewController {
    
    override var title: String? {
        set {}
        
        get {
            return "Master"
        }
    }

    @IBAction func showButtonPressed(_ sender: UIButton) {
        show(MasterViewController(), sender: nil)
    }
    
    @IBAction func showDetailButtonPressed(_ sender: UIButton) {
        showDetailViewController(DetailViewController(), sender: nil)
    }
}
