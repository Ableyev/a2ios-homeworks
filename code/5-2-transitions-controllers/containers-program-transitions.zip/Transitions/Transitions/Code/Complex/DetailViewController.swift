//
//  DetailViewController.swift
//  Transitions
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    override var title: String? {
        set {}
        
        get {
            return "Detail"
        }
    }
}
