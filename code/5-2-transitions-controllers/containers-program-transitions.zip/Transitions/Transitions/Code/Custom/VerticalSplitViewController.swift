//
//  VerticalSplitViewController.swift
//  Transitions
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class VerticalSplitViewController: UIViewController {
    
    var viewControllers: [UIViewController] = [] {
        willSet {
            precondition(newValue.count == 2, "VerticalSplitViewController expects two view controllers")
            
            if (viewControllers.count != 0) {
                let viewControllerTop = viewControllers[0]
                let viewControllerBottom = viewControllers[1]
                
                viewControllerTop.willMove(toParentViewController: nil)
                viewControllerBottom.willMove(toParentViewController: nil)
                
                viewControllerTop.view.removeFromSuperview()
                viewControllerBottom.view.removeFromSuperview()
                
                viewControllerTop.removeFromParentViewController()
                viewControllerBottom.removeFromParentViewController()
            }
        }
        didSet {
            addChildControllers()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addChildControllers()
    }
    
    private func addChildControllers() {
        
        precondition(viewControllers.count == 2, "VerticalSplitViewController expects two view controllers")
        
        let viewControllerTop = viewControllers[0]
        let viewControllerBottom = viewControllers[1]
        
        addChildViewController(viewControllerTop)
        addChildViewController(viewControllerBottom)
        
        view.addSubview(viewControllerTop.view)
        view.addSubview(viewControllerBottom.view)
        
        viewControllerTop.view.translatesAutoresizingMaskIntoConstraints = false
        viewControllerBottom.view.translatesAutoresizingMaskIntoConstraints = false
        
        viewControllerTop.view.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        viewControllerTop.view.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        viewControllerTop.view.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        
        viewControllerBottom.view.topAnchor.constraint(equalTo: viewControllerTop.view.bottomAnchor).isActive = true
        
        viewControllerBottom.view.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        viewControllerBottom.view.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        viewControllerBottom.view.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        
        viewControllerTop.view.heightAnchor.constraint(equalTo: viewControllerBottom.view.heightAnchor).isActive = true
        
        viewControllerTop.didMove(toParentViewController: self)
        viewControllerBottom.didMove(toParentViewController: self)
    }
}
