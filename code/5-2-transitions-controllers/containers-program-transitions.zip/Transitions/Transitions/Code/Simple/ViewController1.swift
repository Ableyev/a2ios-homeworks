//
//  ViewController1.swift
//  Transitions
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ViewController1: UIViewController {

    init(someData: String) {
        super.init(nibName: nil, bundle: nil)
        
        title = someData
    }
    
    @available(*, unavailable, message: "Use init(someData:) instead")
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        fatalError("Use init(someData:) instead of init(nibName:, bundle:)")
    }
    
    @available(*, unavailable, message: "Use init(someData:) instead")
    required init?(coder aDecoder: NSCoder) {
        fatalError("Use init(someData:) instead of init?(coder:)")
    }
    
    override func loadView() {
        view = UIView()
        
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "View controller created in code"
        
        view.addSubview(label)
        
        label.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        label.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
}
