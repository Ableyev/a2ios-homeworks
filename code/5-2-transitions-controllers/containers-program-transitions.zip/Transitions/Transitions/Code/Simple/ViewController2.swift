//
//  ViewController2.swift
//  Transitions
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    override var title: String? {
        set {}
        
        get {
            return "VC 2"
        }
    }
}
