//
//  ViewController.swift
//  UIViewController Life Cycle
//
//  Created by GELICIDE on 18.03.18.
//  Copyright © 2018 com.study. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var viewWillAppearCounter = 0
    var viewWillLayoutSubviewsCounter = 0
    var viewDidDisappearCounter = 0
    
    @IBOutlet weak var awakeFromNibLabel: UILabel!
    @IBOutlet weak var viewDidLoadLabel: UILabel!
    @IBOutlet weak var viewWillLayoutSubviewsLabel: UILabel!
    @IBOutlet weak var viewDidDisappearLabel: UILabel!
    
    @IBOutlet weak var viewWillAppearButton: UIButton!
    // MARK: Initialization

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
        // Designated initializer
        print("Init Bundle")
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        print("Init Coder")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        print("View: \(view)")

        awakeFromNibLabel.backgroundColor = #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1)
        
        print("Awake From Nib")
    }
    
    override func loadView() {
        super.loadView()
        
//        let view = UIView()
//        view.backgroundColor = #colorLiteral(red: 0.4392156899, green: 0.01176470611, blue: 0.1921568662, alpha: 1)
//        self.view = view
        
        print("Load View")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewDidLoadLabel.backgroundColor = #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1)
        
        print("View Did Load")
        
        // Good place to init and setup objects used in the viewController.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        viewWillAppearCounter += 1
        viewWillAppearButton.setTitle("View Will Appear: \(viewWillAppearCounter)", for: .normal)
        
        print("View Will Appear")
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        viewWillLayoutSubviewsCounter += 1
        viewWillLayoutSubviewsLabel.text = "View Will Layout Subview: \(viewWillLayoutSubviewsCounter)"
        
        print("View Will Layout Subviews")
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        print("View Did Layout Subviews")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        print("View Did Appear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("View Will Disappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        viewDidDisappearCounter += 1
        viewDidDisappearLabel.text = "View Did Disappear: \(viewDidDisappearCounter)"
        
        print("View Did Disappear")
    }
    
    deinit {
        print("Deinit")
    }
    
    override func didReceiveMemoryWarning() {
        print("Did Receive Memory Warning")
    }

}
