//
//  ConverterViewController.swift
//  CodeUI
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import Foundation
import UIKit

class СonversionViewController: UIViewController {
    // 1
    private let celsiusToFahrenheitState = СonversionViewState()
    private let fahrenheitToCelsiusState = СonversionViewState()
    private let converter = Converter()
    
    private lazy var resultLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.font = UIFont.resultLabelFont
        label.backgroundColor = UIColor.groupTableViewBackground
        return label
    }()
    
    private lazy var inputTextField: UITextField = {
        let textfield = UITextField()
        textfield.delegate = self
        textfield.placeholder = "Input a value"
        textfield.keyboardType = .numbersAndPunctuation
        textfield.clearButtonMode = .whileEditing
        textfield.autocorrectionType = .no
        textfield.translatesAutoresizingMaskIntoConstraints = false
        textfield.borderStyle = .roundedRect
        return textfield
    }()
    
    private lazy var directionSegmentedControl: UISegmentedControl = {
        let items = ["°C -> °F", "°F -> °C"]
        let control = UISegmentedControl(items: items)
        control.addTarget(self, action: #selector(segmentedControlChangedValue(sender:)), for: .valueChanged)
        control.translatesAutoresizingMaskIntoConstraints = false
        control.selectedSegmentIndex = СonversionDirection.celsiusToFahrenheit.direction()
        return control
    }()
    
    private lazy var convertButton: UIButton = {
        let button = UIButton(type: .roundedRect)
        button.addTarget(self, action: #selector(convertButtonTapped(sender:)), for: .touchUpInside)
        button.isEnabled = false
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Convert", for: .normal)
        button.titleLabel?.font = UIFont.resultLabelFont
        button.setTitleColor(UIColor.black, for: .normal)
        button.setTitleColor(UIColor.lightGray, for: .disabled)
        button.backgroundColor = UIColor.groupTableViewBackground
        return button
    }()
    
    // MARK: - Life cycle
    // 2
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        addSubviews()
        configureConstraints()
    }
    
    // MARK: - Public
    
    func enableConvertButton(enabled: Bool) {
        convertButton.isEnabled = enabled
        
        if !enabled {
            resultLabel.text = ""
        }
    }
    
    // MARK: - Actions
    // 12
    @objc
    private func convertButtonTapped(sender: UIButton) {
        guard let inputText = inputTextField.text,
            let direction = currentDirection(),
            let convertedText = converter.convert(direction: direction, inputText: inputText) else {
                resultLabel.text = "Wrong value"
                return
        }
        
        var resultText: String
        
        if isCelsiusToFahrenheitDirection() {
            resultText = "\(inputText)°C is \(convertedText)°F"
        } else {
            resultText = "\(inputText)°F is \(convertedText)°C"
        }
        resultLabel.text = resultText
    }
    // 13
    @objc
    private func segmentedControlChangedValue(sender: UISegmentedControl) {
        let previousState = isCelsiusToFahrenheitDirection() ? fahrenheitToCelsiusState : celsiusToFahrenheitState
        let currentState = isCelsiusToFahrenheitDirection() ? celsiusToFahrenheitState : fahrenheitToCelsiusState
        previousState.isButtonEnabled = convertButton.isEnabled
        previousState.resultText = resultLabel.text ?? ""
        previousState.textFieldText = inputTextField.text ?? ""
        updateState(currentState)
    }
    
    // MARK: - Private
    // 3
    private func configureConstraints() {
        configureResultLabel()
        configureInputTextField()
        configureConverterSegmentedControl()
        configureConvertButton()
    }
    
    // 14
    private func updateState(_ state: СonversionViewState) {
        convertButton.isEnabled = state.isButtonEnabled
        inputTextField.text = state.textFieldText
        resultLabel.text = state.resultText
    }
    
    private func addSubviews() {
        view.addSubview(resultLabel)
        view.addSubview(inputTextField)
        view.addSubview(directionSegmentedControl)
        view.addSubview(convertButton)
    }
    // 4
    private func configureResultLabel() {
        resultLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8.0).isActive = true
        resultLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: Offset.leading).isActive = true
        resultLabel.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor, constant: 0.0).isActive = true
    }
    // 5
    private func configureInputTextField() {
        // 6
        NSLayoutConstraint(item: inputTextField,
                           attribute: .top,
                           relatedBy: .equal,
                           toItem: resultLabel,
                           attribute: .bottom,
                           multiplier: 1.0,
                           constant: 8.0).isActive = true
        // 7
        NSLayoutConstraint(item: inputTextField,
                           attribute: .leading,
                           relatedBy: .equal,
                           toItem: view.safeAreaLayoutGuide,
                           attribute: .leading,
                           multiplier: 1.0,
                           constant: Offset.leading).isActive = true
        // 8
        NSLayoutConstraint(item: inputTextField,
                           attribute: .width,
                           relatedBy: .equal,
                           toItem: resultLabel,
                           attribute: .width,
                           multiplier: 0.6,
                           constant: 0.0).isActive = true
    }
    // 9
    private func configureConverterSegmentedControl() {
        directionSegmentedControl.centerYAnchor.constraint(equalTo: inputTextField.centerYAnchor, constant: 0.0).isActive = true
        directionSegmentedControl.leadingAnchor.constraint(equalTo: inputTextField.trailingAnchor, constant: Offset.leading).isActive = true
        directionSegmentedControl.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: Offset.trailing).isActive = true
    }
    // 10
    private func configureConvertButton() {
        NSLayoutConstraint.activate([
            convertButton.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor, constant: 0.0),
            convertButton.topAnchor.constraint(equalTo: inputTextField.bottomAnchor, constant: Offset.top),
            convertButton.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, multiplier: 0.5, constant: 0.0)
            ])
    }
}

// 11
extension СonversionViewController: UITextFieldDelegate {
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        self.enableConvertButton(enabled: false)
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let inputText = NSString(string: textField.text ?? "").replacingCharacters(in: range, with: string)
        self.enableConvertButton(enabled: inputText.count != 0)
        return true
    }
    
}

extension СonversionViewController {
    struct Offset {
        static let leading: CGFloat = 16.0
        static let trailing: CGFloat = -16.0
        static let top: CGFloat = 20.0
    }
    
    private func isCelsiusToFahrenheitDirection() -> Bool {
        return directionSegmentedControl.selectedSegmentIndex == СonversionDirection.celsiusToFahrenheit.direction()
    }
    
    private func currentDirection() -> СonversionDirection? {
        return isCelsiusToFahrenheitDirection() ? СonversionDirection.celsiusToFahrenheit : СonversionDirection.fahrenheitToCelsius
    }
}
