//
//  ELNConverter.swift
//  CodeUI
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import Foundation

enum СonversionDirection: Int {
    case celsiusToFahrenheit = 0
    case fahrenheitToCelsius = 1
    
    func direction() -> Int {
        return self.rawValue
    }
}

class Converter {
    
    // MARK: - Public

    func convert(direction: СonversionDirection, inputText: String) -> String? {
        guard let inputNumber = Float(inputText) else {
            return nil
        }
        
        let result = (direction == .celsiusToFahrenheit) ? celsiusToFahrenheit(inputNumber) : fahrenheitToCelsius(inputNumber)
        return String(result)
    }
    
    // MARK: - Private

    private func celsiusToFahrenheit(_ inputValue: Float) -> Float {
        return inputValue * 1.8 + 32.0
    }

    private func fahrenheitToCelsius(_ inputValue: Float) -> Float {
        return (inputValue - 32.0) / 1.8
    }
}
