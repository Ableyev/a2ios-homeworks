//
//  ELNState.swift
//  CodeUI
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import Foundation

class СonversionViewState {
    var isButtonEnabled = false
    var textFieldText = ""
    var resultText = ""
}
