//
//  ViewControllerExtension.swift
//  CodeUI
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import Foundation
import UIKit

extension UIFont {
    static let resultLabelFont = UIFont.systemFont(ofSize: 20.0)
    static let convertButtonFont = UIFont.systemFont(ofSize: 22.0)
}
