//
//  Photo.swift
//  Course2Week3Task2
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

struct Photo {
    let image: UIImage
    let name: String
}
